<template>
  <div id="Register">
    <div class="w-full p-6 flex justify-center items-center">
      <div class="w-full max-w-xs">
        <div class="bg-black p-8 shadow rounded mb-6">
          <h1 class="mb-6 text-lg text-gray-100 font-thin">
            Let's get rocking!
          </h1>

          <div class="mb-4">
            <TextInput label="Frist Name" :labelColor="false" placeHolder="Enter Your First Name"
              v-model:input="fristName" inputType="text" error="This is a text Error" />
          </div>
          <div class="mb-4">
            <TextInput label="Last Name" :labelColor="false" placeHolder="Enter Your Last Name" v-model:input="lastName"
              inputType="text" error="This is a text Error" />
          </div>
          <div class="mb-4">
            <TextInput label="Email" :labelColor="false" placeHolder="(abc@xyz.com)" v-model:input="email"
              inputType="text" error="This is a text Error" />
          </div>
          <div class="mb-4">
            <TextInput label="Password" :labelColor="false" placeHolder="Enter Your password" v-model:input="password"
              inputType="password" error="This is a text Error" />
          </div>
          <div class="mb-4">
            <TextInput label="Confirm Password" :labelColor="false" placeHolder="Re-enter Your Password"
              v-model:input="confirmPassword" inputType="password" />
          </div>
          <button class="block w-full bg-green-500 text-white rounded-sm py-3 text-sm teacking-wide" type="submit">
            Register
          </button>
        </div>
        <p class="text-center text-md text-gray-900">
          Already have an Account?
          <router-link to="login" class="text-blue-500 no-underline hover:underline">
            Login
          </router-link>
        </p>
      </div>
    </div>
  </div>
</template>
<script setup>
import { ref } from "vue";
import TextInput from "../components/global/TextInput.vue";

let fristName = ref(null);
let lastName = ref(null);
let email = ref(null);
let password = ref(null);
let confirmPassword = ref(null);
</script>
