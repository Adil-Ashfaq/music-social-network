<template>
  <div>
    <TopNavigation />
    <HeroSection />
  </div>
</template>

<script setup>
import TopNavigation from "@/components/structure/TopNavigation.vue";
import HeroSection from "@/components/partails/HeroSection.vue";
</script>
