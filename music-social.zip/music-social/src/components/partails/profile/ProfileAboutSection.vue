<template>
    <div class="py-2">
        <p class="text-gray-900 text-lg">
            <b>About me</b>
        </p>
        <p class="text-md md:text-lg text-gray-600 leading-normal">
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Velit enim, nulla debitis consequatur quae eum
            tenetur ipsum laborum magnam eligendi.
        </p>
    </div>
</template>