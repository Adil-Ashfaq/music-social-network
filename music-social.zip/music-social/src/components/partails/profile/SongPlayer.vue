<template>
    <div class="bg-green-500 rounded">
        <div id="aplayer"></div>
    </div>
</template>

<script setup>
import { onMounted } from 'vue';
import APlayer from 'aplayer'
import 'aplayer/dist/APlayer.min.css';

onMounted(() => {
    thePlayer()
})

const thePlayer = () => {
    new APlayer({
        container: document.getElementById('aplayer'),
        audio: [
            {
                name: 'first song',
                artist: 'artist',
                url: '/music/inspiring-emotional-uplifting-piano-112623.mp3',
                cover: 'cover.jpg'
            },
            {
                name: 'second song',
                artist: 'artist',
                url: '/music/cinematic-time-lapse-115672.mp3',
                cover: 'cover.jpg'
            },
            {
                name: 'third song',
                artist: 'artist',
                url: '/music/price-of-freedom-33106.mp3',
                cover: 'cover.jpg'
            }
        ]
    });
}
</script>